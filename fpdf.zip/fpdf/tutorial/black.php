<?php
$image = imagecreate(200, 200);
$black = imagecolorallocate($image, 0x00, 0x00, 0x00);
imagefilledrectangle($image, 0, 0, 200, 200, $black);
header("Content-Type: image/png");
imagepng($image);
?>